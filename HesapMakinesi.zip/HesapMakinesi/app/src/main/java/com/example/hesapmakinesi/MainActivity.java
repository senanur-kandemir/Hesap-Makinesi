package com.example.hesapmakinesi;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView result;
    private EditText girilen;
    private TextView operand;
    private String secim;
    private TextView opDisplay;

    private Double operand1 = null;
    private Double operand2 = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        result = (TextView) findViewById(R.id.result);
        girilen = (EditText) findViewById(R.id.girilen);
        opDisplay = (TextView) findViewById(R.id.text_op);

        Button sayi0 = (Button) findViewById(R.id.sayi0);
        Button sayi1 = (Button) findViewById(R.id.sayi1);
        Button sayi2 = (Button) findViewById(R.id.sayi2);
        Button sayi3 = (Button) findViewById(R.id.sayi3);
        Button sayi4 = (Button) findViewById(R.id.sayi4);
        Button sayi5 = (Button) findViewById(R.id.sayi5);
        Button sayi6 = (Button) findViewById(R.id.sayi6);
        Button sayi7 = (Button) findViewById(R.id.sayi7);
        Button sayi8 = (Button) findViewById(R.id.sayi8);
        Button sayi9 = (Button) findViewById(R.id.sayi9);
        Button topla = (Button) findViewById(R.id.topla);
        Button cıkar = (Button) findViewById(R.id.cıkar);
        Button carp = (Button) findViewById(R.id.carp);
        Button bol = (Button) findViewById(R.id.bol);
        Button esit = (Button) findViewById(R.id.esit);

        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Button button = (Button) view;
                girilen.append((button.getText().toString()));
            }
        };
        sayi0.setOnClickListener(listener);
        sayi1.setOnClickListener(listener);
        sayi2.setOnClickListener(listener);
        sayi3.setOnClickListener(listener);
        sayi4.setOnClickListener(listener);
        sayi5.setOnClickListener(listener);
        sayi6.setOnClickListener(listener);
        sayi7.setOnClickListener(listener);
        sayi8.setOnClickListener(listener);
        sayi9.setOnClickListener(listener);

        esit.setOnClickListener(operationListener);
        topla.setOnClickListener(operationListener);
        cıkar.setOnClickListener(operationListener);
        carp.setOnClickListener(operationListener);
        bol.setOnClickListener(operationListener);
    }

    View.OnClickListener operationListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Button button = (Button) view;
            String op = button.getText().toString();
            String value = girilen.getText().toString();
            try {
                Double deger = Double.valueOf(value);
                performOperation(deger, op);

            } catch (NumberFormatException e) {
                girilen.setText("");
            }
            secim = op;
            opDisplay.setText(secim);
        }
    };

    private void performOperation(Double value, String op) {
        {
            if (operand1 == null) {
                operand1 = value;
            } else
                operand2 = value;
            if (secim.equals("=")) {
                secim = op;
            }


            switch (secim) {
                case "+":
                    operand1 = operand1 + operand2;
                    break;
                case "-":
                    operand1 = operand1 - operand2;
                    break;
                case "*":
                    operand1 = operand1 * operand2;
                    break;
                case "/":
                    if (operand2 == 0) {
                        operand1 = 0.0;
                    } else {
                        operand1 = operand1 / operand2;
                    }
                    break;
                case "=":
                    operand1 = operand2;
                    break;
            }
            result.setText(operand1.toString());
            girilen.setText("");
            opDisplay.setText("");
        }


    }

    @Override
    public void onSaveInstanceState(@Nullable Bundle outState) {
        outState.putString("secim", secim);
        super.onSaveInstanceState(outState);
        if (operand1 != null) {
            outState.putDouble("value", operand1);
        }
    }


    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        secim = savedInstanceState.getString("secim");
        operand1 = savedInstanceState.getDouble("value");
        result.setText((String.valueOf(operand1)));
        opDisplay.setText(secim);
    }
}


